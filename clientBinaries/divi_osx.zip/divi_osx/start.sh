#! /bin/bash

divid -debug 

echo "Divi is starting..."